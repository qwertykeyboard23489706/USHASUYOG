window.USHASUYOG_CONFIG = {
  brandName: "USHASUYOG",
  tagline: "SOUND VIBRATIONAL HEALING & YOGA THERAPY",
  practitioner: "Usha",
  logoPath: "assets/logo/ushasuyog.png",
  audioPath: "assets/audio/alexrockbeat-life-flow-healing-586582.mp3",
  volume: 0.25,
  contact: { phone: "+91 98452 15731", whatsapp: "+91 98452 15731", email: "ushagdongre@gmail.com", instagram: "@soundhealingushasuyog" },
  // Upload photos with these names; animated artwork stays visible until a photo exists.
  galleryImages: [
    { src: "assets/gallery/01Sound%20space%20prepared.jpg", caption: "Sound space prepared", alt: "Sound bowls and instruments arranged for a session" },
    { src: "assets/gallery/02Instruments%20in%20colour.jpg", caption: "Instruments in colour", alt: "Colourful sound bowls and instruments arranged in the practice room" },
    { src: "assets/gallery/03Guided%20sound%20practice.jpg", caption: "Guided sound practice", alt: "Facilitators guiding participants during a sound session" },
    { src: "assets/gallery/04A%20moment%20of%20listening.jpg", caption: "A moment of listening", alt: "A facilitator guiding a small group through a sound practice" },
    { src: "assets/gallery/05Resting%20with%20sound.jpg", caption: "Resting with sound", alt: "Participants resting on mats beside colourful sound bowls" },
    { src: "assets/gallery/06Yoga%20and%20mindful%20movement.jpg", caption: "Yoga and mindful movement", alt: "A group taking part in a guided yoga and wellness session" },
    { src: "assets/gallery/07Shared%20sound%20bath.jpg", caption: "Shared sound bath", alt: "Participants resting together during a group sound bath" },
    { src: "assets/gallery/08Instruments%20at%20rest.jpg", caption: "Instruments at rest", alt: "Sound bowls and instruments prepared in a bright room" },
    { src: "assets/gallery/09Returning%20to%20stillness.jpg", caption: "Returning to stillness", alt: "Participants lying comfortably during a sound meditation" },
    { src: "assets/gallery/10Deep%20rest%2C%20together.jpg", caption: "Deep rest, together", alt: "A group resting on mats during a sound bath" },
    { src: "assets/gallery/11A%20circle%20of%20meditation.jpg", caption: "A circle of meditation", alt: "Participants seated together in a guided meditation" },
    { src: "assets/gallery/12Guided%20group%20session.jpg", caption: "Guided group session", alt: "Facilitators guiding a small group in a wellness session" }
  ],
  images: {
    ushaPortrait: "assets/images/usha-portrait.jpg",
    singingBowls: "assets/images/singing-bowls.jpg",
    listeningPresence: "assets/images/listening-presence.jpg",
    nadaNaad: "assets/images/nada-naad.jpg",
    yogaPresentMoment: "assets/images/YOGA%2C%20BREATHWORK%20%26%20MEDITATION%20Return%20to%20the%20present%20moment.jpg"
  },
  servicesConfirmed: false,
  biographyConfirmed: false
};
