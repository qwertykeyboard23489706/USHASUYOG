(() => {
  const config = window.USHASUYOG_CONFIG || {};
  const audio = document.getElementById("site-audio");
  const welcome = document.getElementById("welcome");
  const enterButton = document.querySelector(".welcome__enter");
  const menuToggle = document.querySelector(".menu-toggle");
  const nav = document.getElementById("primary-nav");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

  // Optional image slots remain hidden until their matching upload is present.
  document.querySelectorAll("[data-site-image]").forEach((image) => {
    const src = config.images?.[image.dataset.siteImage];
    if (!src) { image.remove(); return; }
    image.addEventListener("load", () => {
      image.classList.add("is-loaded");
      image.parentElement?.classList.add("has-photo");
      if (image.classList.contains("about__portrait")) image.parentElement?.classList.add("has-portrait");
    }, { once: true });
    image.addEventListener("error", () => {
      image.parentElement?.classList.remove("has-photo", "has-portrait");
      image.remove();
    }, { once: true });
    image.src = src;
  });

  if (audio) {
    audio.loop = true;
    audio.preload = "auto";
    audio.volume = Number.isFinite(config.volume) ? config.volume : 0.25;
    const attemptPlayback = () => {
      const result = audio.play();
      if (result && typeof result.catch === "function") result.catch(() => {});
    };
    attemptPlayback();
    const startOnFirstInteraction = () => {
      attemptPlayback();
      ["pointerdown", "keydown", "touchstart"].forEach((name) => document.removeEventListener(name, startOnFirstInteraction));
    };
    ["pointerdown", "keydown", "touchstart"].forEach((name) => document.addEventListener(name, startOnFirstInteraction, { once: true, passive: true }));
  }

  const enterSite = () => {
    if (welcome) {
      welcome.classList.add("is-leaving");
      window.setTimeout(() => { welcome.hidden = true; document.body.classList.add("has-entered"); }, reducedMotion.matches ? 0 : 760);
    }
    if (audio && audio.paused) {
      const result = audio.play();
      if (result && typeof result.catch === "function") result.catch(() => {});
    }
  };
  enterButton?.addEventListener("click", enterSite);

  const progressBar = welcome?.querySelector(".welcome__progress");
  const progressFill = progressBar?.querySelector("span");
  const progressNumber = welcome?.querySelector(".progress__edge");
  const progressStatus = document.getElementById("welcome-status");
  const startProgress = () => {
    if (!welcome || welcome.hidden) return;
    welcome.classList.add("welcome--ready");
    const duration = reducedMotion.matches ? 250 : 2200;
    const startedAt = performance.now();
    let previousPercent = -1;
    const step = (now) => {
      const ratio = Math.min(1, (now - startedAt) / duration);
      const eased = 1 - Math.pow(1 - ratio, 3);
      const percent = Math.round(eased * 100);
      if (percent !== previousPercent) {
        if (progressFill) progressFill.style.width = percent + "%";
        if (progressBar) progressBar.setAttribute("aria-valuenow", String(percent));
        if (progressNumber) progressNumber.textContent = percent + "%";
        previousPercent = percent;
      }
      if (ratio < 1) window.requestAnimationFrame(step);
      else if (progressStatus) progressStatus.textContent = "Your space is ready. Take a breath and enter when you are ready.";
    };
    window.setTimeout(() => window.requestAnimationFrame(step), reducedMotion.matches ? 0 : 450);
  };
  const welcomeLogo = welcome?.querySelector("img");
  if (welcomeLogo && !welcomeLogo.complete) {
    welcomeLogo.addEventListener("load", startProgress, { once: true });
    welcomeLogo.addEventListener("error", startProgress, { once: true });
    window.setTimeout(startProgress, 600);
  } else startProgress();

  menuToggle?.addEventListener("click", () => {
    const expanded = menuToggle.getAttribute("aria-expanded") === "true";
    menuToggle.setAttribute("aria-expanded", String(!expanded));
    menuToggle.setAttribute("aria-label", expanded ? "Open navigation" : "Close navigation");
    nav?.classList.toggle("is-open", !expanded);
  });
  document.querySelector(".site-header > .nav__contact")?.addEventListener("click", () => {
    nav?.classList.remove("is-open");
    menuToggle?.setAttribute("aria-expanded", "false");
    menuToggle?.setAttribute("aria-label", "Open navigation");
  });
  nav?.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
    nav.classList.remove("is-open");
    menuToggle?.setAttribute("aria-expanded", "false");
    menuToggle?.setAttribute("aria-label", "Open navigation");
  }));

  const revealItems = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && !reducedMotion.matches) {
    const observer = new IntersectionObserver((entries, currentObserver) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); currentObserver.unobserve(entry.target); }
    }), { threshold: 0.12, rootMargin: "0px 0px -30px 0px" });
    revealItems.forEach((item) => observer.observe(item));
  } else revealItems.forEach((item) => item.classList.add("is-visible"));

  const rippleButton = document.querySelector(".ripple-button");
  rippleButton?.addEventListener("click", () => {
    rippleButton.classList.remove("is-rippling");
    void rippleButton.offsetWidth;
    rippleButton.classList.add("is-rippling");
    window.setTimeout(() => rippleButton.classList.remove("is-rippling"), 2100);
  });

  const artNames = ["Sound space prepared", "Instruments in colour", "Guided sound practice", "A moment of listening", "Resting with sound", "Yoga and mindful movement", "Shared sound bath", "Instruments at rest", "Returning to stillness", "Deep rest, together", "A circle of meditation", "Guided group session"];
  const galleryPhotos = Array.isArray(config.galleryImages) ? config.galleryImages : [];
  const galleryItems = Array.from({ length: Math.max(artNames.length, galleryPhotos.length) }, (_, index) => ({
    name: galleryPhotos[index]?.caption || artNames[index] || "Gallery moment " + (index + 1),
    src: galleryPhotos[index]?.src || "",
    alt: galleryPhotos[index]?.alt || "Ushasuyog gallery photograph " + (index + 1)
  }));
  const gallery = document.getElementById("gallery-grid");
  const lightbox = document.getElementById("lightbox");
  const lightboxArt = lightbox?.querySelector(".lightbox__art");
  const lightboxCaption = lightbox?.querySelector(".lightbox__caption");
  let activeArt = 0;
  const watchGalleryPhoto = (image, container) => {
    image.addEventListener("load", () => image.classList.add("is-loaded"), { once: true });
    image.addEventListener("error", () => {
      image.remove();
      container.classList.remove("has-photo");
    }, { once: true });
  };
  const showArtwork = (index) => {
    activeArt = (index + galleryItems.length) % galleryItems.length;
    const item = galleryItems[activeArt];
    if (lightboxArt) {
      lightboxArt.className = "lightbox__art artwork artwork--" + (activeArt + 1) + (item.src ? " has-photo" : "");
      lightboxArt.replaceChildren();
      if (item.src) {
        const image = document.createElement("img");
        image.className = "lightbox-photo";
        image.src = item.src;
        image.alt = item.alt;
        image.loading = "lazy";
        watchGalleryPhoto(image, lightboxArt);
        lightboxArt.append(image);
      }
    }
    if (lightboxCaption) lightboxCaption.textContent = String(activeArt + 1).padStart(2, "0") + " / " + item.name;
  };
  galleryItems.forEach((item, index) => {
    const number = String(index + 1).padStart(2, "0");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gallery-tile reveal artwork artwork--" + (index + 1) + (item.src ? " has-photo" : "");
    button.setAttribute("aria-label", "Open artwork " + (index + 1) + ": " + item.name);
    if (item.src) {
      const frame = document.createElement("span");
      frame.className = "gallery-photo-frame";
      const image = document.createElement("img");
      image.className = "gallery-photo";
      image.src = item.src;
      image.alt = item.alt;
      image.loading = "lazy";
      watchGalleryPhoto(image, button);
      frame.append(image);
      button.append(frame);
    }
    const caption = document.createElement("span");
    caption.className = "artwork__caption";
    const ordinal = document.createElement("b");
    ordinal.textContent = number;
    const title = document.createElement("span");
    title.textContent = item.name;
    caption.append(ordinal, title);
    button.append(caption);
    button.addEventListener("click", () => {
      showArtwork(index);
      if (typeof lightbox?.showModal === "function") lightbox.showModal();
      else lightbox?.setAttribute("open", "");
      lightbox?.querySelector(".lightbox__close")?.focus();
    });
    gallery?.append(button);
  });  if ("IntersectionObserver" in window && !reducedMotion.matches && gallery) {
    const observer = new IntersectionObserver((entries, currentObserver) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); currentObserver.unobserve(entry.target); }
    }), { threshold: 0.08 });
    gallery.querySelectorAll(".reveal").forEach((item) => observer.observe(item));
  } else gallery?.querySelectorAll(".reveal").forEach((item) => item.classList.add("is-visible"));

  lightbox?.querySelector(".lightbox__close")?.addEventListener("click", () => lightbox.close());
  lightbox?.querySelector(".lightbox__prev")?.addEventListener("click", () => showArtwork(activeArt - 1));
  lightbox?.querySelector(".lightbox__next")?.addEventListener("click", () => showArtwork(activeArt + 1));
  lightbox?.addEventListener("click", (event) => { if (event.target === lightbox) lightbox.close(); });
  lightbox?.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") showArtwork(activeArt - 1);
    if (event.key === "ArrowRight") showArtwork(activeArt + 1);
  });

  const navLinks = nav?.querySelectorAll("a[href^='#']") || [];
  if ("IntersectionObserver" in window) {
    const sectionObserver = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) navLinks.forEach((link) => link.classList.toggle("is-active", link.getAttribute("href") === "#" + entry.target.id));
    }), { rootMargin: "-35% 0px -55% 0px" });
    document.querySelectorAll("main section[id]").forEach((section) => sectionObserver.observe(section));
  }
  const contact = config.contact || {};
  const digits = typeof contact.whatsapp === "string" ? contact.whatsapp.replace(/\D/g, "") : "";
  const makeEnquiryLink = (message) => digits
    ? "https://wa.me/" + digits + "?text=" + encodeURIComponent(message)
    : (contact.email ? "mailto:" + contact.email + "?subject=" + encodeURIComponent(message) : "#contact");
  const bookingLink = document.getElementById("book-session");
  const corporateLink = document.getElementById("corporate-enquiry");
  if (bookingLink && digits) bookingLink.dataset.whatsappMessage = "Hello Ushasuyog, I would like to enquire about booking a session.";
  if (corporateLink && digits) corporateLink.dataset.whatsappMessage = "Hello Ushasuyog, I would like to enquire about corporate wellness.";
  if (bookingLink && !digits && contact.email) bookingLink.href = makeEnquiryLink("Session enquiry");
  if (corporateLink && !digits && contact.email) corporateLink.href = makeEnquiryLink("Corporate wellness enquiry");
  if (digits) document.querySelectorAll("[data-whatsapp-message]").forEach((link) => {
    const message = link.dataset.whatsappMessage || "Hello Ushasuyog.";
    const webUrl = "https://wa.me/" + digits + "?text=" + encodeURIComponent(message);
    const appUrl = "whatsapp://send?phone=" + digits + "&text=" + encodeURIComponent(message);
    link.href = webUrl;
    link.removeAttribute("target");
    link.addEventListener("click", (event) => {
      event.preventDefault();
      let fallbackTimer;
      const cancelFallback = () => {
        window.clearTimeout(fallbackTimer);
        document.removeEventListener("visibilitychange", onVisibilityChange);
        window.removeEventListener("pagehide", cancelFallback);
      };
      const onVisibilityChange = () => { if (document.hidden) cancelFallback(); };
      document.addEventListener("visibilitychange", onVisibilityChange);
      window.addEventListener("pagehide", cancelFallback, { once: true });
      window.location.href = appUrl;
      fallbackTimer = window.setTimeout(() => {
        document.removeEventListener("visibilitychange", onVisibilityChange);
        window.removeEventListener("pagehide", cancelFallback);
        if (!document.hidden) window.location.href = webUrl;
      }, 2200);
    });
  });

  document.getElementById("year").textContent = new Date().getFullYear();
})();
document.addEventListener("visibilitychange", () => document.body.classList.toggle("page-hidden", document.hidden));





